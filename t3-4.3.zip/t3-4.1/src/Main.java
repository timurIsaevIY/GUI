public class Main {
    public static void main(String[] args) {
        Point point1 = new Point(1,1);
        Point point2 = new Point(2,2);
        System.out.println(point1.DistanceTo(point2));
        System.out.println(point2);
    }
}