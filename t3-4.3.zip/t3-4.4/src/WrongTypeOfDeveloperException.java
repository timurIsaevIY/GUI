public class WrongTypeOfDeveloperException extends Exception {
    public WrongTypeOfDeveloperException(String message) {
        super(message);
    }
}
